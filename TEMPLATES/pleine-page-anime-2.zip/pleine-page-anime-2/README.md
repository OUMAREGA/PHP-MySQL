Fullscreen Overlay Styles & Effects
=========

Some simple and creative overlay styles and effects. From sliding the overlay into the viewport to using SVG morphing shapes, we explore some effects for fullscreen overlays.

[Article on Codrops](http://tympanus.net/codrops/?p=18459)

[Demo](http://tympanus.net/Development/FullscreenOverlayStyles/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)